
/* variables lesson, cscie3
*/

// Notice that we don't HAVE TO use the 'var' keyword when first using a variable
//  unless we're in strict mode

"use strict";

var age = prompt("What is your age in years?"); // this is my prompt

console.log("The variable 'age' is of type "+ typeof age);  //just to see

age = age +1;   // I had a birthday!

console.log("Next year I will be " + age);
