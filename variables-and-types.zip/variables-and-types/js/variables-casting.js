
/* video3.2 variables-conversion lesson, cscie3
 * video3.3 strict mode
*/

"use strict";

var age = prompt("What is your age in years?"); // this is my prompt
console.log("The variable 'age' is of type "+ typeof age);

age = Number(age);  //make the variable into a number so we can do math on it
//age = parseInt(age);  //could do it this way, too

console.log("Now, after Number() The variable 'age' is of type "+ typeof age);

age = age + 1;   // I had a birthday!

console.log("Next year I will be " + age);
console.log("Next year I will be " + String(age));
